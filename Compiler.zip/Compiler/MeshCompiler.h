#pragma once
#include <string>
#include <iostream>
#include <filesystem>
#include <fstream>
#include "CompiledModel.h"
#include "MeshBuilder.h"
#include "glm/gtc/type_ptr.hpp"

class MeshCompiler
{
	MeshBuilder* m_pMeshBuilder;

public:

	MeshCompiler(MeshBuilder* mesh_builder) : m_pMeshBuilder{ mesh_builder }
	{

	}

	void CompileMeshes(std::string fbx_directory, std::string nui_directory)
	{
		for (const auto& entry : std::filesystem::directory_iterator(fbx_directory))
		{
			std::string mesh_file_name{ entry.path().filename().generic_string() };
			size_t mesh_file_found = mesh_file_name.find(".fbx");

			if (mesh_file_found == std::string::npos)
			{
				mesh_file_found = mesh_file_name.find(".obj");
			}

			std::string fbx_path{ fbx_directory + "/" + mesh_file_name };

			if (mesh_file_found != std::string::npos)
			{
				std::string name{ mesh_file_name.substr(0, mesh_file_name.find(".")) };
				std::string nui_path{ nui_directory + "/" + name + ".nui" };

				//.nui exists
				if (std::filesystem::is_regular_file(nui_path))
				{
					//compare date modified
					auto obj_time = std::filesystem::last_write_time(fbx_path);
					auto nui_time = std::filesystem::last_write_time(nui_path);

					//is not latest version
					if (nui_time < obj_time)
					{
						//update file
						std::cout << ".nui file for " << mesh_file_name << " is being updated." << std::endl;
						CompileMesh(fbx_path, nui_path);
						std::cout << ".nui file for " << mesh_file_name << " has been updated." << std::endl;
					}

					else
					{
						std::cout << ".nui file for " << mesh_file_name << " is up-to-date." << std::endl;
					}
				}

				//.nui does not exist
				else
				{
					std::cout << ".nui file for " << mesh_file_name << " is not found." << std::endl;

					if (!std::filesystem::is_directory(nui_directory))
					{
						std::filesystem::create_directory(nui_directory);
						std::cout << "Creating directory: " << nui_directory << "." << std::endl;
					}

					std::cout << ".nui file for " << mesh_file_name << " is being created." << std::endl;
					std::ofstream new_nui_file{ nui_path };
					CompileMesh(fbx_path, nui_path);
					std::cout << ".nui file for " << mesh_file_name << " has been created." << std::endl;
				}
			}

			else if (std::filesystem::is_directory(fbx_path))
			{
				std::cout << "Checking folder: " << mesh_file_name << std::endl;
				CompileMeshes(fbx_path, nui_directory + "/" + mesh_file_name);
			}
		}
	}

	void CompileMesh(std::string fbx_name, std::string nui_name)
	{
		std::ofstream ofs;
		ofs.open(nui_name, std::ofstream::out | std::ofstream::trunc);

		CompiledModel model{ m_pMeshBuilder->Build3DMesh(fbx_name) };
		//call the function, updates this model a model

		//put data here and write into the file
		for (auto& sub_mesh : model.GetSubMeshes())
		{
			for (const auto& vertex : sub_mesh.m_Vertices)
			{
				ofs << "VERTEX ";

				ofs << vertex.m_Position.x << " "
					<< vertex.m_Position.y << " "
					<< vertex.m_Position.z << " ";

				ofs << vertex.m_Normal.x << " "
					<< vertex.m_Normal.y << " "
					<< vertex.m_Normal.z << " ";

				ofs << vertex.m_UV.x << " "
					<< vertex.m_UV.y << " ";

				ofs << vertex.m_Tangent.x << " "
					<< vertex.m_Tangent.y << " "
					<< vertex.m_Tangent.z << " ";

				ofs << vertex.m_BiTangent.x << " "
					<< vertex.m_BiTangent.y << " "
					<< vertex.m_BiTangent.z << " ";

				ofs << vertex.m_BoneIDs[0] << " "
					<< vertex.m_BoneIDs[1] << " "
					<< vertex.m_BoneIDs[2] << " "
					<< vertex.m_BoneIDs[3] << " ";

				ofs << vertex.m_Weights[0] << " "
					<< vertex.m_Weights[1] << " "
					<< vertex.m_Weights[2] << " "
					<< vertex.m_Weights[3] << std::endl;
			}

			ofs << "INDEX ";

			for (auto& index : sub_mesh.m_Indices)
			{
				ofs << index << " ";
			}

			ofs << std::endl;

			auto compile_mat_data = [&](std::string mat_data_name) {

				if (mat_data_name.empty())
				{
					ofs << "EMPTY ";
				}

				else
				{
					ofs << mat_data_name << " ";
				}
			};

			ofs << "MATERIAL " << sub_mesh.m_Material.first << " ";

			compile_mat_data(sub_mesh.m_Material.second.m_Ambient.first);
			ofs << " " << sub_mesh.m_Material.second.m_Ambient.second << " ";

			compile_mat_data(sub_mesh.m_Material.second.m_Diffuse.first);
			ofs << " " << sub_mesh.m_Material.second.m_Diffuse.second << " ";

			compile_mat_data(sub_mesh.m_Material.second.m_Specular.first);
			ofs << " " << sub_mesh.m_Material.second.m_Specular.second << " ";

			compile_mat_data(sub_mesh.m_Material.second.m_Normal.first);
			ofs << " " << sub_mesh.m_Material.second.m_Normal.second << std::endl;
		}

		for (auto bone : model.GetBoneInfoMap())
		{
			ofs << "BONE " << bone.first << " " << bone.second.id << " ";

			glm::mat4 offset{ bone.second.offset };
			
			for (int i = 0; i < 16; ++i)
			{
				ofs << static_cast<float*>(glm::value_ptr(offset))[i] << " ";
			}

			ofs << std::endl;
		}

		for (auto animation : model.GetAnimations())
		{
			ofs << "ANIMATION " << animation.first << " ";

			ofs << animation.second.GetDuration() << " " << animation.second.GetTicksPerSecond() << std::endl;

			for (auto anim_bone : animation.second.GetBones())
			{
				ofs << "ANIMATIONBONE ";
				float check_time_stamp{-INFINITY};

				for (const auto& positions : anim_bone.m_Positions)
				{
					if (check_time_stamp < positions.m_TimeStamp)
					{
						check_time_stamp = positions.m_TimeStamp;

						ofs << "POSITION ";

						ofs << positions.m_Position.x << " "
							<< positions.m_Position.y << " "
							<< positions.m_Position.z << " "
							<< positions.m_TimeStamp << " ";
					}
				}

				check_time_stamp = -INFINITY;

				for (const auto& rotation : anim_bone.m_Rotations)
				{
					if (check_time_stamp < rotation.m_TimeStamp)
					{
						check_time_stamp = rotation.m_TimeStamp;

						ofs << "ROTATION ";

						ofs << rotation.m_Orientation.w << " "
							<< rotation.m_Orientation.x << " "
							<< rotation.m_Orientation.y << " "
							<< rotation.m_Orientation.z << " "
							<< rotation.m_TimeStamp << " ";
					}
				}

				check_time_stamp = -INFINITY;

				for (const auto& scale : anim_bone.m_Scales)
				{
					if (check_time_stamp < scale.m_TimeStamp)
					{
						check_time_stamp = scale.m_TimeStamp;

						ofs << "SCALE ";

						ofs << scale.m_Scale.x << " "
							<< scale.m_Scale.y << " "
							<< scale.m_Scale.z << " "
							<< scale.m_TimeStamp << " ";
					}
				}

				ofs << "END ";

				glm::mat4 trans{ anim_bone.m_LocalTransform };

				for (int i = 0; i < 16; ++i)
				{
					ofs << static_cast<float*>(glm::value_ptr(trans))[i] << " ";
				}

				ofs << anim_bone.m_Name << " " << anim_bone.m_ID << std::endl;
			}

			NodeData& root_node{ animation.second.GetRootNode() };
			CompileNodeData(root_node, {}, ofs);

			for (auto& bone_info : animation.second.GetBoneIDMap())
			{
				ofs << "BONEINFO " << bone_info.first << " " << bone_info.second.id << " ";

				glm::mat4 offset{ bone_info.second.offset };

				for (int i = 0; i < 16; ++i)
				{
					ofs << static_cast<float*>(glm::value_ptr(offset))[i] << " ";
				}

				ofs << std::endl;
			}

			ofs << "ANIMATIONEND" << std::endl;
		}

		ofs << "TYPE " << model.GetPrimitive() << std::endl;
	}

	void CompileNodeData(NodeData& node_data, std::string parent_name, std::ofstream& ofs)
	{
		if (parent_name.empty())
		{
			ofs << "ROOTNODE ";
		}

		else
		{
			ofs << "NODEDATA " << parent_name << " ";
		}

		for (int i = 0; i < 16; ++i)
		{
			ofs << static_cast<float*>(glm::value_ptr(node_data.transformation))[i] << " ";
		}

		ofs << node_data.name << std::endl;

		for (auto& child : node_data.children)
		{
			CompileNodeData(child, node_data.name, ofs);
		}
	}
};